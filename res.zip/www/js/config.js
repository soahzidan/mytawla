
var krms_config ={					
	'ApiUrl':"https://mytawla.com/merchantapp/api",
	'DialogDefaultTitle':"MYTAWLA",
	'APIHasKey':"0q1w2e3r4t5y6u7i8o9p0a1s2d3f4g5h6j7k8l",
	'debug': false
};